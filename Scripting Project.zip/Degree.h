#include <string>
#pragma once
using namespace std;

//Enum Class with Degree Optionas
enum class DegreeProgram { SECURITY, NETWORK, SOFTWARE };


#pragma once
